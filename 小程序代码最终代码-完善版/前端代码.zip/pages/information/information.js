// pages/information/information.js
Page({

  /**
   * Page initial data
   */
  data: {
    identityS: false,
    identityT: false,
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad(options) {
    var key=wx.getStorageSync('token');
    var info=wx.getStorageSync('userinfo');
    console.log(key);
    if(key.identity==1){
      this.setData({
        student_number: key.studentNumber,
        student_name: key.studentName,
        // asset_number: key.assetNumber,
        // asset_class: key.assetClass,
        screen_code: key.screenCode,
        host_code: key.hostCode,
        station_number: key.stationNumber,
        tel_number: key.telNumber,
        imagesrc: info.avatarUrl,
        username: info.nickName,
        identityS: true,
      })
    }else {
      this.setData({
        teacher_number: key.teacherNumber,
        teacher_name: key.teacherName,
        tel_number: key.telNumber,
        imagesrc: info.avatarUrl,
        username: info.nickName,
        identityT: true,
      })
    }
  },
  formSubmit(e){
    // console.log(e.detail.value);
    console.log(e.detail.value);
    var key=wx.getStorageSync('token');
    if(key.identity==1){
      let {student_number,student_name,screen_code, host_code, station_number, tel_number} = e.detail.value;  
      wx.request({
        url: 'https://www.ylsda.shop:9000/wechat/updateInfo',
        method: "POST",
        data: {
          studentNumber: student_number,
          studentName: student_name,
          screenCode: screen_code,
          hostCode: host_code,
          stationNumber: station_number,
          telNumber: tel_number,
          identity: key.identity
        },
        success: (res)=>{
         console.log(res);
         if(res.data.mark==1){
         wx.showToast({
          title: '提交成功！',
         });
         this.setData({
          student_number: res.data.studentNumber,
          student_name: res.data.studentName,
          screen_code: res.data.screenCode,
          host_code: res.data.hostCode,
          station_number: res.data.stationNumber,
          tel_number: res.data.telNumber,
        });
        } else{
          wx.showToast({
            title: '提交失败',
            icon: 'error',
            duration: 2000
          });
          this.setData({
            student_number: key.studentNumber,
            student_name: key.studentName,
            screen_code: key.screenCode,
            host_code: key.hostCode,
            station_number: key.stationNumber,
            tel_number: key.telNumber,
          });
        }
        },
        fail: (res)=>{
          wx.showToast({
           title: '提交失败！',
          });
         }
      });
    }else{
      let { teacher_number,teacher_name,tel_number} = e.detail.value;  
      wx.request({
        url: 'https://www.ylsda.shop:9000/wechat/updateInfo',
        method: "POST",
        data: {
          teacherNumber: teacher_number,
          teacherName: teacher_name,
          telNumber: tel_number,
          identity: key.identity
        },
        success: (res)=>{
          if(res.data.mark==1){
          wx.showToast({
            title: '提交成功！',
           });
          this.setData({
            teacher_number: res.data.teacherNumber,
            teacher_name: res.data.teacherName,
            tel_number: res.data.telNumber,
          })
        } else{
          wx.showToast({
            title: '提交失败',
            icon: 'error',
            duration: 2000
          });
          this.setData({
            teacher_number: key.teacherNumber,
            teacher_name: key.teacherName,
            tel_number: key.telNumber,
          })
        }
        },
        fail: (res)=>{
          wx.showToast({
           title: '提交失败！',
          });
         }
      });
    }
  },
  exit(){
      // 清除本地用户授权信息
      wx.setStorageSync('userinfo', null);
      // 清除本地token
      wx.setStorageSync('token', null);
      if(wx.getStorageSync('userinfo')==null){
        wx.redirectTo({
          url: '../login/login'        
        })
      }else{
        wx.showToast({
          title: '退出失败',
        })
      }
  },
  scancode: function(e) {
    var that = this;
    console.log(e.currentTarget.dataset.code);
    var name=e.currentTarget.dataset.code;
    if(name=='screen_code'){
      wx: wx.scanCode({
        // onlyFromCamera: true,
        scanType: [],
        success: function(res) {
          that.setData({
            screen_code: res.result,
         
          })
        },
        fail: function(res) {},
        complete: function(res) {},
      })
    }else if(name=='host_code'){
      wx: wx.scanCode({
        // onlyFromCamera: true,
        scanType: [],
        success: function(res) {
          that.setData({
            host_code: res.result,
            station_number: res.stationNumber,
          })
        },
        fail: function(res) {},
        complete: function(res) {},
      })
    }else {
      wx: wx.scanCode({
        // onlyFromCamera: true,
        scanType: [],
        success: function(res) {
          that.setData({
            station_number: res.result,
          })
        },
        fail: function(res) {},
        complete: function(res) {},
      })
    }
  },
  scancode2: function() {
    //点击事件
    const that = this;
    wx.chooseMedia({
      success: (res) => {
        //获取图片的临时路径
        // console.log(res.tempFiles[0].tempFilePath);
        const tempFilePath = res.tempFiles[0].tempFilePath
        //根据官方的要求  用base64字符编码获取图片的内容
        wx.getFileSystemManager().readFile({
          filePath: tempFilePath,
          encoding: 'base64',
          success: function (res) {
            //调用方法
            that.getImgInfo(res.data)
          },
        })
      },
    })
  

  },
  getImgInfo: function (imageData) {
    wx.showLoading({
      title: '识别中...',
    })
    var that = this
    that.getToken().then(res => {
      console.log(res)
      //获取token
      const token = res.data.slice(243,315);
      console.log(token)
      const detectUrl = `https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic?access_token=${token}` // baiduToken是已经获取的access_Token      
      wx.request({
        url: detectUrl,
        data: {
          image: imageData
        },
        method: 'POST',
        dataType: 'json',
        header: {
          'content-type': 'application/x-www-form-urlencoded' // 必须的        
        },
        success: function (res, resolve) {
          console.log(res)
          //将 res.data.words_result数组中的内容加入到words中           
          that.setData({
            station_number: res.data.words_result[0].words
          })
          console.log(res)
          console.log(res.data.words_result[0].words)
          wx.hideLoading()
        },
        fail: function (res, reject) {
          console.log('get word fail：', res.data);
          wx.hideLoading()
        },
        complete: function () {
          wx.hideLoading()
        }
      })
    })
  },
  // 获取百度access_token  
  getToken: function () {
      return new Promise(resolve => {
        var APIKEY = "hfdzBAtlgwLEi8D6DqWqjpas"
        var SECKEY = "G9oxcRV2eNqPdD1oEVnrAyxefMAke17M"
        var tokenUrl = `https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=${APIKEY}&client_secret=${SECKEY}`
        var that = this;

        console.log(tokenUrl);
        wx.request({
          url: tokenUrl,
          method: 'POST',
          dataType: 'application/json',
          header: {
            'content-type': 'application/json; charset-UTF-8'
            
          },
          success: function (res) { 
            console.log("Token获取成功", res);
            return resolve(res) ;
          
          },
          fail: function (res) {
            console.log("Token获取失败", res);
            return resolve(res)
          }
        })
      })
  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady() {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow() {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide() {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload() {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh() {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom() {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage() {

  }
})